# 这里面都是远古版本MIUI才有的目录
/system/app/MSA-CN-NO_INSTALL_PACKAGE
/system/app/mid_test
/system/app/FidoCryptoService
/system/app/AutoTest
/system/app/SeempService
/system/app/GPSLogSave
/system/app/SYSOPT
/system/app/Qmmi
/system/app/Xman
/system/app/Yman
/system/app/seccamsample
/system/priv-app/dpmserviceapp
/system/product/priv-app/dpmserviceapp
/system/product/app/datastatusnotification
/system/product/priv-app/seccamservice
/system/vendor/app/GFManager
/system/vendor/app/GFTest
