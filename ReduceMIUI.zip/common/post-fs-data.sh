#!/system/bin/sh
MODDIR=${0%/*}
rm -rf /data/vendor/charge_logger/
